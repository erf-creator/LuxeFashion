
import React from 'react';

interface NavbarProps {
  cartCount: number;
  onOpenCart: () => void;
  onSearchChange: (query: string) => void;
}

const Navbar: React.FC<NavbarProps> = ({ cartCount, onOpenCart, onSearchChange }) => {
  return (
    <nav className="sticky top-0 z-40 w-full bg-white/80 backdrop-blur-md border-b border-gray-100 px-6 py-4">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => window.location.reload()}>
          <span className="text-2xl font-serif font-bold tracking-tighter">LUXE<span className="text-indigo-600">FASHION</span></span>
        </div>

        <div className="flex-1 w-full max-w-md mx-4">
          <div className="relative">
            <input
              type="text"
              placeholder="Search brands, styles, or categories..."
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full bg-gray-100 border-none rounded-full py-2 px-10 focus:ring-2 focus:ring-indigo-500 transition-all outline-none text-sm"
            />
            <svg
              className="absolute left-3 top-2.5 h-4 w-4 text-gray-400"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <button className="text-gray-600 hover:text-indigo-600 font-medium text-sm transition-colors hidden md:block">Collections</button>
          <button className="text-gray-600 hover:text-indigo-600 font-medium text-sm transition-colors hidden md:block">About</button>
          <button 
            onClick={onOpenCart}
            className="relative p-2 text-gray-700 hover:bg-gray-100 rounded-full transition-all"
          >
            <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
            </svg>
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-indigo-600 text-white text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full border-2 border-white">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
