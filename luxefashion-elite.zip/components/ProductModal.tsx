
import React, { useState } from 'react';
import { Product } from '../types';

interface ProductModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (product: Product, size: string, color: string) => void;
}

const ProductModal: React.FC<ProductModalProps> = ({ product, isOpen, onClose, onAddToCart }) => {
  if (!product || !isOpen) return null;

  const [selectedSize, setSelectedSize] = useState(product.sizes[0]);
  const [selectedColor, setSelectedColor] = useState(product.colors[0].name);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div 
        className="absolute inset-0 bg-gray-900/60 backdrop-blur-sm animate-fade-in"
        onClick={onClose}
      />
      
      <div className="relative bg-white w-full max-w-5xl max-h-[90vh] overflow-y-auto rounded-2xl shadow-2xl flex flex-col md:flex-row animate-fade-in">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 bg-white/80 hover:bg-white rounded-full transition-colors shadow-sm"
        >
          <svg className="h-6 w-6 text-gray-900" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        {/* Image Gallery */}
        <div className="md:w-1/2 h-full">
          <img 
            src={product.image} 
            alt={product.name}
            className="w-full h-full object-cover min-h-[400px] md:min-h-[600px]"
          />
        </div>

        {/* Product Info */}
        <div className="md:w-1/2 p-8 md:p-12 flex flex-col">
          <div className="mb-6">
            <span className="text-indigo-600 font-bold uppercase tracking-widest text-sm">{product.brand}</span>
            <h2 className="text-3xl md:text-4xl font-serif font-bold mt-2 text-gray-900 leading-tight">
              {product.name}
            </h2>
            <p className="text-gray-500 font-medium mt-1">Model: {product.model}</p>
            <p className="text-3xl font-bold text-gray-900 mt-4">${product.price}</p>
          </div>

          <div className="mb-8 space-y-4">
            <h4 className="font-bold text-gray-900 border-b border-gray-100 pb-2">Description</h4>
            <p className="text-gray-600 leading-relaxed">{product.description}</p>
            
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="block text-gray-400 font-medium uppercase tracking-tighter text-[10px]">Material</span>
                <span className="text-gray-900 font-semibold">{product.material}</span>
              </div>
              <div>
                <span className="block text-gray-400 font-medium uppercase tracking-tighter text-[10px]">Collection</span>
                <span className="text-gray-900 font-semibold">{product.category}</span>
              </div>
            </div>
          </div>

          {/* Color Selector */}
          <div className="mb-6">
            <h4 className="text-sm font-bold text-gray-900 mb-3">Color: <span className="font-normal text-gray-500">{selectedColor}</span></h4>
            <div className="flex gap-3">
              {product.colors.map((color) => (
                <button
                  key={color.name}
                  onClick={() => setSelectedColor(color.name)}
                  className={`w-8 h-8 rounded-full border-2 transition-all p-0.5 ${selectedColor === color.name ? 'border-indigo-600 ring-2 ring-indigo-200' : 'border-transparent'}`}
                >
                  <div 
                    className="w-full h-full rounded-full shadow-inner"
                    style={{ backgroundColor: color.hex }}
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Size Selector */}
          <div className="mb-10">
            <h4 className="text-sm font-bold text-gray-900 mb-3">Size: <span className="font-normal text-gray-500">{selectedSize}</span></h4>
            <div className="flex flex-wrap gap-2">
              {product.sizes.map((size) => (
                <button
                  key={size}
                  onClick={() => setSelectedSize(size)}
                  className={`px-4 py-2 border-2 text-sm font-bold transition-all rounded-lg ${selectedSize === size ? 'border-indigo-600 bg-indigo-50 text-indigo-600' : 'border-gray-100 hover:border-gray-300 text-gray-700'}`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-auto flex gap-4">
            <button 
              onClick={() => onAddToCart(product, selectedSize, selectedColor)}
              className="flex-1 bg-gray-900 text-white font-bold py-4 rounded-xl hover:bg-indigo-600 transition-all flex items-center justify-center gap-2 group"
            >
              <svg className="h-5 w-5 group-hover:scale-110 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
              </svg>
              Add to Bag
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductModal;
